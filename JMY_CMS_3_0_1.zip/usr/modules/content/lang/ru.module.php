<?php

/**
* @name        JMY CMS
* @link        http://jmy.su/
* @copyright   Copyright (C) 2012-2014 JMY LTD
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      Komarov Ivan
*/

//define('_NEWS', 'Новости');
define('_N_LINK', 'Ваш IP:');
define('_N_DATE', 'Ваш IP:');
