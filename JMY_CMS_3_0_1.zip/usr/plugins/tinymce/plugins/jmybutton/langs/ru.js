tinymce.addI18n('ru',{
    'Insert mail'   : "Вставить почту",
	'Insert mail adress'   : "Вставить адрес почты",
	'Input mail'   : "Адрес почты",
	'Insert quote'   : "Вставить цитату",
	'Insert hidden text'   : "Вставить скрытый текст",
	'Insert spoiler'   : "Вставить спойлер",
	'Insert audio'   : "Вставить аудио",
	'Insert video'   : "Вставить видео",
});