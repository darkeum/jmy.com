<?php
if (!defined('ACCESS')) 
{
    header('Location: /');
    exit;
}


$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'test';

$prefix = 'JMY';
$user_prefix = 'JMY';
$user_db = 'test';

