<?php

/**
* @name        JMY CMS
* @link        http://jmy.su/
* @copyright   Copyright (C) 2012-2014 JMY LTD
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      Komarov Ivan
*/

define('_APFEEDBACK', 'Feedback');
define('_APFEEDBACK_MAIN', 'Basic options');
define('_APFEEDBACK_MAIN_ALLOW_ATTACHT', 'To resolve attachment');
define('_APFEEDBACK_MAIN_ALLOW_ATTACHD', 'To allow to fill in in feedback files:');
define('_APFEEDBACK_MAIN_FORMATST', 'Admissible formats');
define('_APFEEDBACK_MAIN_FORMATSD', 'The formats resolved for loading');
define('_APFEEDBACK_MAIN_FILE_SIZET', 'File size');
define('_APFEEDBACK_MAIN_FILE_SIZED', 'As much as possible admissible size of a file');