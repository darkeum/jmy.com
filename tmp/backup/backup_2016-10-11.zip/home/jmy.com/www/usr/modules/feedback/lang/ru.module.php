<?php

/**
* @name        JMY CMS
* @link        http://jmy.su/
* @copyright   Copyright (C) 2012-2016 JMY LTD
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      Komarov Ivan
*/
define('_FEEDBACK', 'Обратная связь');
define('_FEEDBACK_SENDINGMESS', 'Отправка сообщения');
define('_FEEDBACK_SENDOK', 'Ваше сообщение отправлено');
define('_FEEDBACK_SENDFALSE', 'Не заполнены обязательные поля формы, вернитесь назад и заполните недостающие поля!');
define('_FEEDBACK_NAME', 'Ваше имя');
define('_FEEDBACK_EMAIL', 'Ваш E-Mail');
define('_FEEDBACK_TOPIC', 'Тема');
define('_FEEDBACK_ATTACH', 'Прикрепить вложение');
define('_FEEDBACK_MESSAGE', 'Сообщение');
define('_FEEDBACK_FILE_FORMAT', 'Досутпные форматы');
define('_FEEDBACK_FILE_SIZE', 'Максимальный размер файла');
define('_FEEDBACK_HELLO', 'Здравствуйте!');
define('_FEEDBACK_LETTER_FORMS', 'Получено письмо из формы обратной связи.');
define('_FEEDBACK_EMAIL_FORMS', 'E-mail для связи');
define('_FEEDBACK_SINCERELY', 'С уважением, администрация');