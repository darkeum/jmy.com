tinymce.addI18n('it',{
    'YouTube Tooltip'   : "YouTube",
	'YouTube Title'     : "Inserisci un video di Youtube",
	'Youtube URL'       : 'Condividi URL',
	'Youtube ID'        : 'http://youtu.be/xxxxxxxx o http://www.youtube.com/watch?v=xxxxxxxx',
	'width'             : 'Larghezza',
	'height'            : 'Altezza',
	'autoplay'          : 'Autoplay',
	'Related video'     : 'Video correlati',
	'HD video'          : 'Guarda in HD',
    'cancel'            : 'Annullare',
    'Insert'            : 'Inserisci'
});