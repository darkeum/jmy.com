CREATE TABLE `[prefix]_sm_mail` (
  `id` int(5) NOT NULL auto_increment,
  `topic` varchar(255) default NULL,
  `text` text,
  `date` int(11) NOT NULL,
  `uid` int(1) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 PACK_KEYS=0 AUTO_INCREMENT=1 ;

CREATE TABLE `[prefix]_sm_users` (
  `user_id` int(11) unsigned NOT NULL auto_increment,
  `user_email` varchar(100) NOT NULL,
  `user_name` varchar(50) default NULL,
  `user_sol` char(3) NOT NULL,
  `user_reg_date` int(11) NOT NULL,
  `user_ip` varchar(15) default '0',
  `active` int(1) NOT NULL default '1',
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 PACK_KEYS=0 AUTO_INCREMENT=3 ;