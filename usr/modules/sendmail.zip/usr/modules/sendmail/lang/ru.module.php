<?php
define('_SENDMAIL', 'Подписка на рассылку');
define('_SENDMAIL_EMAIL_ERROR', 'Укажите адрес электронной почты');
define('_SENDMAIL_EMAIL_ERROR_ENTER', 'Некоректно введен EMail адрес, пожалуйста исправьте ошибки!');
define('_SENDMAIL_SUBSCRIBERS', 'Вы уже подписаны на рассылку');
define('_SENDMAIL_SUBSCRIBE_SUCCESS', 'Вы успешно подписаны на рассылку');
define('_SENDMAIL_SUBSCRIBE_ERROR', 'Извините, Вы не смогли подписаться. Обратитесь к администратору');