<?php

if (!defined('ACCESS')) {
    header('Location: /');
    exit;
}

loadConfig('sendmail');

switch(isset($url[1]) ? $url[1] : null) 
{
	default:
		set_title(array(_SENDMAIL));
		$core->tpl->loadFile('sendmail');
		$core->tpl->end();
		break;	
	
	case "subscribe":
		set_title(array(_SENDMAIL));
if (isset($_POST['act'])) {$act = $_POST['act']; $act = trim($act); $act = stripslashes($act); $act = htmlspecialchars($act);}
if (isset($_POST['name'])) {$name = $_POST['name']; $name = trim($name); $name = stripslashes($name); $name = htmlspecialchars($name);}
if (isset($_POST['email'])) {$email = $_POST['email']; $email = trim($email); $email = stripslashes($email); $email = htmlspecialchars($email);	}

			if(!empty($name) && empty($email))
		{
			$core->tpl->info("<strong>".$name."</strong> " . _SENDMAIL_EMAIL_ERROR . "", 'warning');
		$osh = 1;
		}

if (isset($act) && $act=='podpis' && !empty($email))
{

		if (preg_match('/^[ёа-яА-Яa-zA-Z0-9_\.\-]+\@([ёа-яА-Яa-zA-Z0-9\-]+\.)+[ёа-яА-Яa-zA-Z0-9]{2,4}$|^$/', $email))
		{ 
		
		}
		else
		{
			$core->tpl->info(_SENDMAIL_EMAIL_ERROR_ENTER, 'warning');
		$osh = 1;
		}

		$query = $db->query("SELECT `user_email` FROM `" . DB_PREFIX . "_sm_users` WHERE `user_email`='{$email}'",$db);
		if($db->numRows($query) > 0)
		{
			$core->tpl->info("<strong>".$name."</strong> - <strong>".$email."</strong> " . _SENDMAIL_SUBSCRIBERS . "");
			$osh = 1;
		}

		if ($osh!= 1)
		{
		$ip = $_SERVER['REMOTE_ADDR'];
		
		//отправка заяки на почту	

		function usersl($n=3)
		{
			$key = '';
			$pattern = '1234567890abcdefghijklmnopqrstuvwxyz.,*_-=+';
			$counter = strlen($pattern)-1;
			for($i=0; $i<$n; $i++)
			{
				$key .= $pattern{rand(0,$counter)};
			}
			return $key;
		}


		$user_sol = usersl();
		$date = time();
		
		if (empty($name)) { $name="Пользователь"; }
		
		$headers=null;
		$headers.="Content-Type: text/html; charset=" . $config['charset'] . "\r\n";
		$headers.="From: " . $sendmail_conf['name'] . " <" . $sendmail_conf['email'] . ">\r\n";
		$headers.="X-Mailer: JMY Mail\r\n";
		$msg="<html><head><meta http-equiv='Content-Type' content='text/html; charset=" . $config['charset'] . "'>
		<style>BODY {FONT-FAMILY: verdana,arial,helvetica; FONT-SIZE: 12px; } TD {FONT-SIZE: 12px;} .sm {FONT-SIZE: 9px;}</style>
		</head>
		<body><center><br><br><strong>".$name."</strong>, Вы успешно подписаны на рассылку — ". $sendmail_conf['name'] ."</center><br /><br /><br />
		<table border=1 cellpadding=6 cellspacing=0 width=500 bordercolor='#f2f2f2'>
		<tr><td>Ваше имя:</td><td>".$name."</td></tr>
		<tr><td>Ваш EMail:</td><td>".$email."</td></tr>
		<tr><td colspan='2' class='sm'><br />Не отвечайте на это сообщение, так как оно генерируется автоматически 
		и служит только для информативных целей</td></tr>		
		
		</table><br><br><br><br>С уважением, администрация " . $config['name'] . "
		</body></html>";		
		mail($email, "Подписка на рассылку — ".$sendmail_conf['name'], $msg, $headers);

		//админу
		$headers=null;
		$headers.="Content-Type: text/html; charset=" . $config['charset'] . "\r\n";
		$headers.="From: " . $sendmail_conf['name'] . " <" . $sendmail_conf['email'] . ">\r\n";
		$headers.="X-Mailer: JMY Mail\r\n";
		$msg="<html><head><meta http-equiv='Content-Type' content='text/html; charset=" . $config['charset'] . "'>
		<style>BODY {FONT-FAMILY: verdana,arial,helvetica; FONT-SIZE: 12px; } TD {FONT-SIZE: 12px;}</style>
		</head>
		<body><center><br><br>Новый подписчик на рассылку — ".$sendmail_conf['name']."</center><br><br><br>
		<table border=1 cellpadding=6 cellspacing=0 width=500 bordercolor='#f2f2f2'>
		<tr><td>ip адресс:</td><td>".$ip."</td></tr>
		<tr><td>Имя подписчика:</td><td>".$name."</td></tr>
		<tr><td>EMail подписчика:</td><td>".$email."</td></tr>
		</table><br /><br /><br /><br /><a target=_blank href=http://jmy.su/>Система управления сайтом JMY CMS</a>
		</body></html>";		
		mail($sendmail_conf['email'], "Новый подписчик на рассылку — ".$sendmail_conf['name'], $msg, $headers);
		$query = $db->query("INSERT INTO `" . DB_PREFIX . "_sm_users`
									   (`user_ip`,`user_reg_date`,`user_name`,`user_sol`,`user_email`) 
										VALUES ('{$ip}','{$date}','{$name}','{$user_sol}','{$email}')",$db);
		
		if ($query == 'true') 
			{ 
				$core->tpl->info("<strong>".$name."</strong> " . _SENDMAIL_SUBSCRIBE_SUCCESS . " " . $sendmail_conf['name'] . "");
			}
		else 
			{ 
				$core->tpl->info(_SENDMAIL_SUBSCRIBE_ERROR, 'warning'); 
			}
		
		}
}
		break;
}
