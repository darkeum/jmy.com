# 
# MySQL database dump
# Created by MySQL_Backup class, ver. 1.0.1
# 
# Host: localhost
# Generated: Sep 18, 2016 at 11:31
# MySQL version: 5.5.25
# PHP version: 5.4.45
# 
# Database: `11`
# 


# 
# Table structure for table `jmy_attach`
# 

DROP TABLE IF EXISTS `jmy_attach`;
CREATE TABLE `jmy_attach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `url` varchar(255) NOT NULL,
  `pub_id` varchar(255) DEFAULT NULL,
  `mod` varchar(55) NOT NULL,
  `downloads` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pub_id` (`pub_id`),
  KEY `url` (`url`),
  KEY `pub_id_2` (`pub_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_attach`
# 



# 
# Table structure for table `jmy_blocks_types`
# 

DROP TABLE IF EXISTS `jmy_blocks_types`;
CREATE TABLE `jmy_blocks_types` (
  `title` varchar(55) DEFAULT NULL,
  `type` varchar(55) NOT NULL,
  PRIMARY KEY (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_blocks_types`
# 

LOCK TABLES jmy_blocks_types WRITE;
INSERT INTO `jmy_blocks_types` (`title`,`type`) VALUES ('����� �����','left'),('������ �����','right'),('������ ������','bannertop');
UNLOCK TABLES;


# 
# Table structure for table `jmy_blog_posts`
# 

DROP TABLE IF EXISTS `jmy_blog_posts`;
CREATE TABLE `jmy_blog_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `comments` int(11) NOT NULL,
  `views` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `ratingUsers` text NOT NULL,
  `tags` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bid` (`bid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_blog_posts`
# 



# 
# Table structure for table `jmy_blog_readers`
# 

DROP TABLE IF EXISTS `jmy_blog_readers`;
CREATE TABLE `jmy_blog_readers` (
  `bid` int(11) NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_blog_readers`
# 



# 
# Table structure for table `jmy_blogs`
# 

DROP TABLE IF EXISTS `jmy_blogs`;
CREATE TABLE `jmy_blogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `altname` varchar(55) NOT NULL,
  `description` text NOT NULL,
  `avatar` varchar(200) NOT NULL,
  `posts` int(11) NOT NULL,
  `readersNum` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `lastUpdate` int(11) NOT NULL,
  `admins` varchar(255) NOT NULL,
  `readers` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_blogs`
# 



# 
# Table structure for table `jmy_board_forums`
# 

DROP TABLE IF EXISTS `jmy_board_forums`;
CREATE TABLE `jmy_board_forums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(55) NOT NULL,
  `description` varchar(255) NOT NULL,
  `pid` int(11) NOT NULL,
  `type` varchar(3) NOT NULL,
  `active` smallint(1) NOT NULL,
  `open` smallint(1) NOT NULL,
  `threads` int(11) NOT NULL,
  `posts` int(11) NOT NULL,
  `lastPost` varchar(55) NOT NULL,
  `lastPoster` varchar(255) NOT NULL,
  `lastTid` int(11) NOT NULL,
  `lastSubject` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rulestitle` varchar(255) NOT NULL,
  `rules` text NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_board_forums`
# 



# 
# Table structure for table `jmy_board_permissions`
# 

DROP TABLE IF EXISTS `jmy_board_permissions`;
CREATE TABLE `jmy_board_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fid` int(11) NOT NULL,
  `gid` int(11) NOT NULL,
  `allowView` int(1) NOT NULL,
  `allowRead` int(1) NOT NULL,
  `allowCreate` int(1) NOT NULL,
  `allowReply` int(1) NOT NULL,
  `allowEdit` int(1) NOT NULL,
  `allowModer` int(1) NOT NULL,
  `allowAttach` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_board_permissions`
# 



# 
# Table structure for table `jmy_board_posts`
# 

DROP TABLE IF EXISTS `jmy_board_posts`;
CREATE TABLE `jmy_board_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) NOT NULL,
  `message` text NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `files` text NOT NULL,
  `visible` varchar(1) NOT NULL,
  `editUser` varchar(55) NOT NULL,
  `editReason` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 PACK_KEYS=0;

# 
# Dumping data for table `jmy_board_posts`
# 



# 
# Table structure for table `jmy_board_threads`
# 

DROP TABLE IF EXISTS `jmy_board_threads`;
CREATE TABLE `jmy_board_threads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `forum` int(11) NOT NULL,
  `title` varchar(55) NOT NULL,
  `poster` int(11) NOT NULL,
  `startTime` varchar(55) NOT NULL,
  `lastTime` varchar(55) NOT NULL,
  `lastPoster` varchar(55) NOT NULL,
  `views` int(11) NOT NULL,
  `replies` int(11) NOT NULL,
  `important` int(1) NOT NULL DEFAULT '0',
  `closed` int(1) NOT NULL DEFAULT '0',
  `score` float(6,3) NOT NULL,
  `votes` smallint(5) NOT NULL,
  `icon` varchar(44) NOT NULL,
  `closetime` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 PACK_KEYS=0;

# 
# Dumping data for table `jmy_board_threads`
# 



# 
# Table structure for table `jmy_board_users`
# 

DROP TABLE IF EXISTS `jmy_board_users`;
CREATE TABLE `jmy_board_users` (
  `uid` int(11) NOT NULL,
  `thanks` int(11) NOT NULL,
  `messages` int(11) NOT NULL,
  `specStatus` varchar(255) DEFAULT ' ',
  `lastUpdate` int(11) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_board_users`
# 

LOCK TABLES jmy_board_users WRITE;
INSERT INTO `jmy_board_users` (`uid`,`thanks`,`messages`,`specStatus`,`lastUpdate`) VALUES ('1','0','0',' ','0');
UNLOCK TABLES;


# 
# Table structure for table `jmy_categories`
# 

DROP TABLE IF EXISTS `jmy_categories`;
CREATE TABLE `jmy_categories` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `altname` varchar(55) NOT NULL,
  `description` varchar(200) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `module` varchar(55) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `position` smallint(5) NOT NULL,
  `parent_id` smallint(5) NOT NULL,
  PRIMARY KEY (`id`,`altname`),
  KEY `altname` (`altname`),
  KEY `parent_id` (`parent_id`),
  KEY `module` (`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_categories`
# 



# 
# Table structure for table `jmy_com_subscribe`
# 

DROP TABLE IF EXISTS `jmy_com_subscribe`;
CREATE TABLE `jmy_com_subscribe` (
  `id` int(11) NOT NULL,
  `module` varchar(55) NOT NULL,
  `uid` int(11) NOT NULL,
  UNIQUE KEY `id` (`id`,`module`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_com_subscribe`
# 



# 
# Table structure for table `jmy_comments`
# 

DROP TABLE IF EXISTS `jmy_comments`;
CREATE TABLE `jmy_comments` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `uid` smallint(5) NOT NULL,
  `post_id` smallint(5) NOT NULL,
  `module` varchar(55) NOT NULL,
  `text` text,
  `date` varchar(44) NOT NULL,
  `gemail` varchar(55) NOT NULL,
  `gname` varchar(55) NOT NULL,
  `gurl` varchar(55) NOT NULL,
  `parent` int(11) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `module` (`module`),
  KEY `post_id` (`post_id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_comments`
# 

LOCK TABLES jmy_comments WRITE;
INSERT INTO `jmy_comments` (`id`,`uid`,`post_id`,`module`,`text`,`date`,`gemail`,`gname`,`gurl`,`parent`,`status`) VALUES ('1','0','2','news','dawdawdawdawd','1472921966','vaneka97@ya.ru','����� - awdawd','','0','1');
UNLOCK TABLES;


# 
# Table structure for table `jmy_content`
# 

DROP TABLE IF EXISTS `jmy_content`;
CREATE TABLE `jmy_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `translate` varchar(255) NOT NULL,
  `cat` varchar(200) NOT NULL,
  `keywords` varchar(55) NOT NULL,
  `active` int(1) NOT NULL,
  `date` varchar(55) DEFAULT NULL,
  `comments` int(11) NOT NULL,
  `theme` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_content`
# 



# 
# Table structure for table `jmy_gallery_albums`
# 

DROP TABLE IF EXISTS `jmy_gallery_albums`;
CREATE TABLE `jmy_gallery_albums` (
  `album_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `trans` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `views` int(11) NOT NULL,
  `nums` int(11) NOT NULL,
  `last_update` varchar(250) NOT NULL,
  `last_author` varchar(250) NOT NULL,
  `last_image` varchar(250) NOT NULL,
  `watermark` int(1) DEFAULT NULL,
  `sizes` text NOT NULL,
  `gropups_allow` int(11) NOT NULL,
  `dir` varchar(255) NOT NULL,
  PRIMARY KEY (`album_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_gallery_albums`
# 



# 
# Table structure for table `jmy_gallery_photos`
# 

DROP TABLE IF EXISTS `jmy_gallery_photos`;
CREATE TABLE `jmy_gallery_photos` (
  `photo_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `author` varchar(250) NOT NULL,
  `add_date` varchar(250) NOT NULL,
  `photo_date` varchar(250) NOT NULL,
  `photos` text NOT NULL,
  `tech` text NOT NULL,
  `views` int(11) NOT NULL,
  `gets` int(11) NOT NULL,
  `comments` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `ratings` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `groups_allow` int(11) NOT NULL,
  PRIMARY KEY (`photo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_gallery_photos`
# 



# 
# Table structure for table `jmy_groups`
# 

DROP TABLE IF EXISTS `jmy_groups`;
CREATE TABLE `jmy_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guest` int(1) NOT NULL,
  `user` int(1) NOT NULL,
  `moderator` int(1) NOT NULL,
  `admin` int(1) NOT NULL,
  `banned` int(1) NOT NULL,
  `showHide` int(1) NOT NULL,
  `showAttach` int(1) NOT NULL,
  `loadAttach` int(1) NOT NULL,
  `addPost` int(1) NOT NULL,
  `addComment` int(1) NOT NULL,
  `allowRating` int(1) NOT NULL,
  `maxWidth` int(11) NOT NULL,
  `maxPms` int(11) NOT NULL,
  `control` text NOT NULL,
  `icon` varchar(255) NOT NULL,
  `color` varchar(55) NOT NULL,
  `points` int(11) NOT NULL,
  `protect` int(1) NOT NULL,
  `special` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_groups`
# 

LOCK TABLES jmy_groups WRITE;
INSERT INTO `jmy_groups` (`id`,`name`,`guest`,`user`,`moderator`,`admin`,`banned`,`showHide`,`showAttach`,`loadAttach`,`addPost`,`addComment`,`allowRating`,`maxWidth`,`maxPms`,`control`,`icon`,`color`,`points`,`protect`,`special`) VALUES ('1','��������������','1','1','1','1','0','0','1','1','1','1','1','100','50','','media/groups/administrator.png','red','0','1','0'),('3','�����','1','0','0','0','0','0','1','0','1','1','1','100','50','','media/groups/3.png','','0','0','0'),('4','����','1','0','0','0','0','0','0','0','0','0','0','0','0','','media/groups/4.png','','0','1','0'),('2','������������','1','1','0','0','0','0','1','0','1','1','1','100','50','','media/groups/user.png','blue','0','1','0'),('5','���������','0','0','0','0','1','0','0','0','0','0','0','0','0','','','','0','0','0');
UNLOCK TABLES;


# 
# Table structure for table `jmy_guestbook`
# 

DROP TABLE IF EXISTS `jmy_guestbook`;
CREATE TABLE `jmy_guestbook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `date` varchar(55) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `website` varchar(75) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `comment` text NOT NULL,
  `reply` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_guestbook`
# 



# 
# Table structure for table `jmy_langs`
# 

DROP TABLE IF EXISTS `jmy_langs`;
CREATE TABLE `jmy_langs` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `postId` varchar(255) DEFAULT NULL,
  `module` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `short` text,
  `full` text,
  `lang` varchar(255) NOT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_langs`
# 

LOCK TABLES jmy_langs WRITE;
INSERT INTO `jmy_langs` (`_id`,`postId`,`module`,`title`,`short`,`full`,`lang`) VALUES ('1','1','news','����� �������������','<p><audio src=\"http://jmy.com/files/news/1/Alex%20Clare%20-%20Too%20Close%20(DJ%20Sergey%20Fisun%20remix).mp3\" controls=\"controls\">Alex Clare - Too Close (DJ Sergey Fisun remix)</audio></p>\n<p><a title=\"Your idea is not bad\" href=\"http://jmy.com/files/news/1/Your%20idea%20is%20not%20bad.docx\">Your idea is not bad</a></p>','','ru'),('2','2','news','dfvdfv','<p>���</p>','','ru');
UNLOCK TABLES;


# 
# Table structure for table `jmy_logs`
# 

DROP TABLE IF EXISTS `jmy_logs`;
CREATE TABLE `jmy_logs` (
  `time` int(5) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `uid` int(5) NOT NULL,
  `history` varchar(255) NOT NULL,
  `level` smallint(1) NOT NULL,
  PRIMARY KEY (`time`),
  KEY `level` (`level`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_logs`
# 

LOCK TABLES jmy_logs WRITE;
INSERT INTO `jmy_logs` (`time`,`ip`,`uid`,`history`,`level`) VALUES ('1472889342','127.0.0.1','1','���� admin � ������ ����������.','1'),('1472889395','127.0.0.1','1','���� admin � ������ ����������.','1'),('1472989308','127.0.0.1','1','���� admin � ������ ����������.','1'),('1473099332','127.0.0.1','1','���� admin � ������ ����������.','1'),('1473508396','127.0.0.1','1','���� admin � ������ ����������.','1'),('1473693673','127.0.0.1','1','���� admin � ������ ����������.','1'),('1473782322','127.0.0.1','1','���� admin � ������ ����������.','1'),('1474178343','127.0.0.1','1','���� admin � ������ ����������.','1');
UNLOCK TABLES;


# 
# Table structure for table `jmy_news`
# 

DROP TABLE IF EXISTS `jmy_news`;
CREATE TABLE `jmy_news` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `author` varchar(55) NOT NULL,
  `date` int(11) DEFAULT NULL,
  `tags` varchar(255) NOT NULL,
  `cat` varchar(200) DEFAULT NULL,
  `altname` varchar(55) NOT NULL,
  `keywords` text,
  `description` text,
  `allow_comments` int(1) NOT NULL,
  `allow_rating` int(1) NOT NULL,
  `allow_index` int(1) NOT NULL,
  `score` float(6,3) DEFAULT NULL,
  `votes` smallint(5) NOT NULL,
  `views` smallint(5) NOT NULL,
  `comments` smallint(5) NOT NULL,
  `fields` text NOT NULL,
  `groups` varchar(55) NOT NULL,
  `fixed` int(1) NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `altname` (`altname`),
  KEY `active` (`active`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_news`
# 

LOCK TABLES jmy_news WRITE;
INSERT INTO `jmy_news` (`id`,`author`,`date`,`tags`,`cat`,`altname`,`keywords`,`description`,`allow_comments`,`allow_rating`,`allow_index`,`score`,`votes`,`views`,`comments`,`fields`,`groups`,`fixed`,`active`) VALUES ('1','admin','1457385120','',',0,','jetapy_stroitelstva','','Array','1','1','1','0.000','0','26','0','',',0,','0','1'),('2','admin','1471245360','',',0,','dfvdfv','','Array','1','1','1','0.000','0','14','1','',',0,','0','1');
UNLOCK TABLES;


# 
# Table structure for table `jmy_online`
# 

DROP TABLE IF EXISTS `jmy_online`;
CREATE TABLE `jmy_online` (
  `uid` int(11) NOT NULL,
  `time` int(10) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `group` int(11) NOT NULL,
  `url` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_online`
# 

LOCK TABLES jmy_online WRITE;
INSERT INTO `jmy_online` (`uid`,`time`,`ip`,`group`,`url`) VALUES ('1','1474191074','127.0.0.1','1','/news');
UNLOCK TABLES;


# 
# Table structure for table `jmy_plugins`
# 

DROP TABLE IF EXISTS `jmy_plugins`;
CREATE TABLE `jmy_plugins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(55) NOT NULL,
  `content` text NOT NULL,
  `file` varchar(55) NOT NULL,
  `priority` tinyint(2) unsigned NOT NULL,
  `type` varchar(55) DEFAULT NULL,
  `service` varchar(44) NOT NULL,
  `showin` varchar(255) NOT NULL,
  `unshow` varchar(255) NOT NULL,
  `groups` varchar(255) NOT NULL,
  `free` tinyint(1) unsigned NOT NULL,
  `template` text,
  `active` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `active` (`active`),
  KEY `priority` (`priority`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_plugins`
# 

LOCK TABLES jmy_plugins WRITE;
INSERT INTO `jmy_plugins` (`id`,`title`,`content`,`file`,`priority`,`type`,`service`,`showin`,`unshow`,`groups`,`free`,`template`,`active`) VALUES ('1','blog','����','','0',NULL,'modules','','bannertop','','0',NULL,'1'),('2','board','�����','','0',NULL,'modules','','','','0',NULL,'1'),('3','content','��������','','0',NULL,'modules','','','','0',NULL,'1'),('5','feedback','�������� �����','','0',NULL,'modules','','','','0',NULL,'1'),('6','gallery','�������','','0',NULL,'modules','','','','0',NULL,'1'),('7','news','�������','','0',NULL,'modules','','','','0',NULL,'1'),('8','pm','������ ���������','','0',NULL,'modules','','','','0',NULL,'1'),('9','profile','�������','','0',NULL,'modules','','','','0',NULL,'1'),('10','search','�����','','0',NULL,'modules','','','','0',NULL,'1'),('11','guestbook','�������� �����','','0',NULL,'modules','','','','0',NULL,'1'),('12','sitemap','����� �����','','0',NULL,'modules','','','','0',NULL,'1'),('13','feed','����� ���������','','0',NULL,'modules','','','','0',NULL,'1');
UNLOCK TABLES;


# 
# Table structure for table `jmy_pm`
# 

DROP TABLE IF EXISTS `jmy_pm`;
CREATE TABLE `jmy_pm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `toid` int(11) NOT NULL,
  `fromid` int(11) NOT NULL,
  `message` text,
  `time` varchar(55) NOT NULL,
  `status` smallint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_pm`
# 



# 
# Table structure for table `jmy_poll_questions`
# 

DROP TABLE IF EXISTS `jmy_poll_questions`;
CREATE TABLE `jmy_poll_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `variant` varchar(55) NOT NULL,
  `position` smallint(5) NOT NULL,
  `vote` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_poll_questions`
# 



# 
# Table structure for table `jmy_poll_voting`
# 

DROP TABLE IF EXISTS `jmy_poll_voting`;
CREATE TABLE `jmy_poll_voting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `ip` varchar(55) NOT NULL,
  `time` varchar(55) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_poll_voting`
# 



# 
# Table structure for table `jmy_polls`
# 

DROP TABLE IF EXISTS `jmy_polls`;
CREATE TABLE `jmy_polls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `votes` int(5) NOT NULL,
  `max` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_polls`
# 



# 
# Table structure for table `jmy_ratings`
# 

DROP TABLE IF EXISTS `jmy_ratings`;
CREATE TABLE `jmy_ratings` (
  `_` int(11) NOT NULL AUTO_INCREMENT,
  `id` smallint(5) NOT NULL,
  `uid` smallint(5) NOT NULL,
  `mod` varchar(55) NOT NULL,
  `time` int(11) NOT NULL,
  `ip` varchar(55) NOT NULL,
  PRIMARY KEY (`_`),
  KEY `mod` (`mod`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_ratings`
# 



# 
# Table structure for table `jmy_sitemap`
# 

DROP TABLE IF EXISTS `jmy_sitemap`;
CREATE TABLE `jmy_sitemap` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `url` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_sitemap`
# 

LOCK TABLES jmy_sitemap WRITE;
INSERT INTO `jmy_sitemap` (`id`,`name`,`url`) VALUES ('1','������� ��������','http://jmy.com/'),('2','����','http://jmy.com/blog'),('3','�����','http://jmy.com/board'),('4','��������','http://jmy.com/content'),('5','�������� �����','http://jmy.com/feedback'),('6','�������','http://jmy.com/gallery'),('7','�������� �����','http://jmy.com/guestbook'),('8','�������','http://jmy.com/news'),('9','����� �������������','http://jmy.com/news/jetapy_stroitelstva.html'),('10','����� �����','http://jmy.com/sitemap');
UNLOCK TABLES;


# 
# Table structure for table `jmy_tags`
# 

DROP TABLE IF EXISTS `jmy_tags`;
CREATE TABLE `jmy_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag` varchar(55) NOT NULL,
  `module` varchar(55) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `module` (`module`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_tags`
# 



# 
# Table structure for table `jmy_user_carma`
# 

DROP TABLE IF EXISTS `jmy_user_carma`;
CREATE TABLE `jmy_user_carma` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `from` int(11) NOT NULL,
  `to` int(11) NOT NULL,
  `text` varchar(255) NOT NULL,
  `do` varchar(5) DEFAULT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_user_carma`
# 



# 
# Table structure for table `jmy_user_friends`
# 

DROP TABLE IF EXISTS `jmy_user_friends`;
CREATE TABLE `jmy_user_friends` (
  `who_invite` int(9) NOT NULL,
  `whom_invite` int(9) NOT NULL,
  `confirmed` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_user_friends`
# 



# 
# Table structure for table `jmy_user_visitors`
# 

DROP TABLE IF EXISTS `jmy_user_visitors`;
CREATE TABLE `jmy_user_visitors` (
  `id` int(9) NOT NULL,
  `visitor` int(9) NOT NULL,
  `time` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_user_visitors`
# 



# 
# Table structure for table `jmy_users`
# 

DROP TABLE IF EXISTS `jmy_users`;
CREATE TABLE `jmy_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nick` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tail` varchar(55) NOT NULL,
  `email` varchar(255) NOT NULL,
  `provider` varchar(255) NOT NULL,
  `social_id` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `icq` varchar(55) NOT NULL,
  `skype` varchar(55) NOT NULL,
  `surname` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  `ochestvo` varchar(55) NOT NULL,
  `place` varchar(255) NOT NULL,
  `age` int(3) NOT NULL,
  `sex` int(1) NOT NULL,
  `birthday` varchar(55) NOT NULL,
  `hobby` varchar(255) NOT NULL,
  `signature` text,
  `points` int(11) DEFAULT '0',
  `carma` int(11) NOT NULL,
  `user_comments` int(11) NOT NULL,
  `user_news` int(11) NOT NULL,
  `group` int(11) NOT NULL,
  `exgroup` int(3) NOT NULL,
  `last_visit` int(11) NOT NULL,
  `regdate` int(11) NOT NULL,
  `active` int(1) NOT NULL,
  `ip` varchar(55) NOT NULL,
  `fields` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nick_2` (`nick`),
  KEY `nick` (`nick`),
  KEY `ip` (`ip`),
  KEY `active` (`active`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_users`
# 

LOCK TABLES jmy_users WRITE;
INSERT INTO `jmy_users` (`id`,`nick`,`password`,`tail`,`email`,`provider`,`social_id`,`status`,`icq`,`skype`,`surname`,`name`,`ochestvo`,`place`,`age`,`sex`,`birthday`,`hobby`,`signature`,`points`,`carma`,`user_comments`,`user_news`,`group`,`exgroup`,`last_visit`,`regdate`,`active`,`ip`,`fields`) VALUES ('1','admin','e73e95900a30a26af54e3392febd6b5c','83p4ak43pt','','','',NULL,'','','','','','','0','0','','',NULL,'20','0','0','2','1','0','1472927193','0','1','127.0.0.1',''),('2','zzverr','21d6d027dde7b0e8c0771a111905cd1f','zwpbkp6a','vaneka97@yandex.ru','','',NULL,'','admin','','','','','0','0','','','wad','0','0','0','0','2','0','1472922410','1472922015','1','127.0.0.1','');
UNLOCK TABLES;


# 
# Table structure for table `jmy_xfields`
# 

DROP TABLE IF EXISTS `jmy_xfields`;
CREATE TABLE `jmy_xfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `type` smallint(1) NOT NULL,
  `content` text NOT NULL,
  `to_user` int(1) NOT NULL,
  `module` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# 
# Dumping data for table `jmy_xfields`
# 



