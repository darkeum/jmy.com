tinymce.addI18n('fr_FR',{
    'YouTube Tooltip'   : "YouTube",
	'YouTube Title'     : "Insertion d'une vidéo youtube",
	'Youtube URL'	    : 'URL YouTube',
	'Youtube ID'        : 'http://youtu.be/xxxxxxxx ou http://www.youtube.com/watch?v=xxxxxxxx',
	'width'			    : 'Largeur',
	'height'		    : 'Hauteur',
	'autoplay'		    : 'Autoplay',
	'Related video'     : 'Vidéos similaires',
	'HD video'          : 'Visionner en HD',
    'cancel'            : 'Annuler',
    'Insert'            : 'Insertion'
});