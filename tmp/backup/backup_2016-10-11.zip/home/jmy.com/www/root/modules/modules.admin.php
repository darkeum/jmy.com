<?php

/**
* @name        JMY CMS
* @link        http://jmy.su/
* @copyright   Copyright (C) 2012-2014 JMY LTD
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      Komarov Ivan
*/
 
if (!defined('ADMIN_ACCESS')) {
    header('Location: /');
    exit;
}

$modArr[] = '';

$query = $db->query("SELECT * FROM ".DB_PREFIX."_plugins WHERE service='modules'");
while($_mod = $db->getRow($query)) 
{
	$modArr[] = $_mod['title'];
	
	if(!file_exists(ROOT.'usr/modules/'.$_mod['title'].'/index.php'))
	{
		delete($_mod['id']);
	}
}

$path = ROOT.'usr/modules/';
$dh = opendir($path);
while ($file = readdir($dh)) 
{
	if(!in_array($file, $modArr) && file_exists($path.$file.'/index.php')) 
	{
		$db->query("INSERT INTO `" . DB_PREFIX . "_plugins` (`title` , `content` , `service`  , `active` ) VALUES ('" . $file . "', '" . ucfirst($file) . "', 'modules', '1');");
	}
	delcache('plugins');
}
closedir($dh);

function delete($id, $path = '') {
global $adminTpl, $db;
	$db->query("DELETE FROM `" . DB_PREFIX . "_plugins` WHERE `id` = " . $id . " LIMIT 1");
	if($path != '') full_rmdir(ROOT . 'usr/modules/'.$path.'/');
}

function retivate($id) {
global $adminTpl, $db;
	$db->query("UPDATE `" . DB_PREFIX . "_plugins` SET `active` = NOT `active` WHERE `id` = " . $id . " LIMIT 1 ;");
}


$server_domain = 'http://server.jmy.su/';
switch(isset($url[2]) ? $url[2] : null) {
	default:
		$adminTpl->admin_head('Модули системы');
		if(isset($url[2]) && $url[2] == 'ok')
		{
			$adminTpl->info('Действия успешно выполнены!');
		}
		echo '
		<div class="row">
			<div class="col-lg-12">
				<section class="panel">
					<div class="panel-heading">
						<b>Список модулей:</b>						
					</div>
					<div class="panel-body no-padding">
					<form id="tablesForm" style="margin:0; padding:0" method="POST" action="{ADMIN}/modules/action">
						<table class="table no-margin">
							<thead>
								<tr>
									<th class="col-md-1"><span class="pd-l-sm"></span>ID</th>
									<th class="col-md-3">Название</th>
									<th class="col-md-1">Описание</th>
									<th class="col-md-3">Админка</th>
									<th class="col-md-2">Группы</th>
									<th class="col-md-2">Действия</th>								
									<th class="col-md-1"><input type="checkbox" name="all" onclick="setCheckboxes(\'tablesForm\', true); return false;"></th>
								</tr>
							</thead>
							<tbody>';
		$query = $db->query("SELECT * FROM ".DB_PREFIX."_plugins WHERE service='modules' ORDER BY title ASC");

		if($db->numRows($query) > 0) 
		{
			while($mod = $db->getRow($query)) 
			{
				$status_icon = ($mod['active'] == 0) ? '<a href="{ADMIN}/modules/retivate/' . $mod['id'] . '" onClick="return getConfirm(\'' . _ACTIVATE . ' - ' . $mod['title'] . '?\')" title="' . _ACTIVATE . '" class="activate"><button type="button" class="btn btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Активировать">A</button></a>' : '<a href="{ADMIN}/modules/retivate/' . $mod['id'] . '" onClick="return getConfirm(\'' . _DEACTIVATE . ' - ' . $mod['title'] . '?\')" title="' . _DEACTIVATE . '" class="deactivate"><button type="button" class="btn btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Деактивировать">D</button></a></a>';
				echo "
				<tr>
					<td><span class=\"pd-l-sm\"></span>" . $mod['id'] . "</td>
					<td>" . $mod['title'] . "</td>
					<td>" . $mod['content'] . "</td>
					<td>" . (file_exists(ROOT.'usr/modules/'.$mod['title'].'/admin/index.php') ? '<font color="green">Да</font>' : '<font color="red">Нет</font>') . "</td>
					<td>" . ($mod['groups'] == '' ? '<i>Все</i>' : $mod['groups']) . "</td>
					<td>";
				echo $status_icon .'
				<a href="{ADMIN}/modules/edit/'. $mod['id'] .'">
				<button type="button" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Редактировать">E</button>
				</a>
				<a href="{ADMIN}/modules/delete/'. $mod['id'] .'" onclick="return getConfirm(\'Удалить модуль - '. $mod['title'] .'?\')">
				<button type="button" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Удалить">X</button>
				</a>';
				echo "</td>
					<td> <input type=\"checkbox\" name=\"checks[]\" value=\"" . $mod['id'] . "\"></td>
				</tr>";	
			}
		} 
		else 
		{
			echo '<tr><td colspan="8" align="center">Модулей нет.. это явный сбой в системе.</td></tr>';
		}
	
		echo '<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>
		
		<div align="right">
	<table>
	<tbody><tr>
	<td valign="top">
	<input name="submit" type="submit" class="btn btn-success" id="sub" value="Де/Активировать"><span class="pd-l-sm"></span>
	</td>
	</tr>
	</tbody></table>
	<br>	
	</div>
</form></div>
</section></div></div>';
		$adminTpl->admin_foot();
	break;		
	
	case 'server':
		$adminTpl->admin_head('Модули | Загрузка модулей');	
		$chmod_files = array('usr/modules', 'usr/blocks', 'usr/plugins');
		foreach($chmod_files as $dir)
		{
			if(!is_writable(ROOT.$dir))
			{
				$write_error[] = 'Директория ' . $dir . ' недоступна для записи, установка модулей может быть некорректной. Установите права 777 на данную папку';
			}
		}
		
		if(!empty($write_error))
		{
			$adminTpl->info(implode($write_error, '<br />'));
		}
		$query_search = '';
		$cat_list = explode('|', @file_get_contents($server_domain.'modules.php?cat_list'));		
		echo '<div class="row">
					<div class="col-lg-12">
						<section class="panel">
						   <header class="panel-heading">Навигация 
												<div style="float:right">Сортировать по: [ <a href="administration/user/order/abc">алфавиту</a> | <a href="administration/user/order/last">последний визит</a> | <a href="administration/user/order/uid">id</a> ]</div></header>

                                                <div class="panel-body">
												<table width="100%">
												<tbody><tr>
												<td><div class="wrap">';
		if(!empty($cat_list))
		{
			foreach($cat_list as $li)
			{
				$cl = '';
				$cat_li = explode('-', $li);				
				switch ($cat_li[1]) {
				case "block":
					$cl = "primary";
					break;
				case "modules":
					$cl = "success";
					break;
				case "plagin":
					$cl = "warning";
					break;
				}
				echo '<button id="' . $cat_li[1] . '" type="button" onclick="ajaxGet(\'' . ADMIN . '/modules/ajax/cat/' . $cat_li[1] . '\', \'_div\'); setbold(\'' . $cat_li[1] . '\');" class="btn btn-'.$cl.'">' . $cat_li[0] . '</button> ';
			
			}
		}
		else
		{
			echo 'Соединение с центром не установлено';
		}
		echo ' <script>
				   var wrap = $(\'.wrap > button\');

					wrap.click(function (){
					  $(this).toggleClass(\'btn-outline\');
					  $(\'.wrap > button\').not($(this)).removeClass(\'btn-outline\');
					});
				  </script></div></td>
												<td>
                                                    <form class="form-inline" role="form" align="right"  onsubmit="ajaxGet(\'' . ADMIN . '/modules/ajax/search/\'+gid(\'querys\').value, \'_div\'); return false;">
													 <div class="form-group">
                                                            <label class="sr-only" for="exampleInputEmail2">Поиск:</label>
                                                            <input type="text" name="query" id="querys" value="' . $query_search . '" class="form-control" >
                                                        </div>
														<button type="submit" class="btn btn-default">Найти</button>
                                                    </form>
												</td>
											</tr>
										</tbody></table>
                                                </div>
                                            </section>
                                        </div>
                                    </div>';   
		echo '<div class="row">
							<div class="col-lg-12">
								<section class="panel">
									<div class="panel-heading"><b>Каталог</b></div>
									<div id="_div" class="panel-body no-padding">
										<div class="panel-heading" >Идёт загрузка информации с сервера...</div>
										<script type="text/javascript">ajaxGet(\'' . ADMIN . '/modules/ajax/main\', \'_div\');</script>	
									</div>
								</section>
							</div>
						</div>';		
		$adminTpl->admin_foot();
		break;
		
	case 'upload':
		$adminTpl->admin_head('Модули | Загрузка модулей');	
		$chmod_files = array('usr/modules', 'usr/blocks', 'usr/plugins');
		foreach($chmod_files as $dir)
		{
			if(!is_writable(ROOT.$dir))
			{
				$write_error[] = 'Директория ' . $dir . ' недоступна для записи, установка модулей может быть некорректной. Установите права 777 на данную папку';
			}
		}
		
		if(!empty($write_error))
		{
			$adminTpl->info(implode($write_error, '<br />'));
		}
		echo '<div class="row">
					<div class="col-lg-12">
						<section class="panel">
                              <header class="panel-heading">Загрузка модулей</header>
                                                <div class="panel-body">
													<form onsubmit="ajaxGet(\'' . ADMIN . '/modules/ajax/install/\'+encodeURI(gid(\'_url\').value), \'_div\'); return false;">
														<b>Загрузить пакет с модулем через ссылку:</b><br><br>
														<div class="form-group">
                                                            <label class="sr-only" for="exampleInputEmail2">Введите новое имя файла/директории: </label>
                                                            <input type="text" id="_url" name="_url" class="form-control" size=40" value="http://">
															<br>
															<font color="red">Внимание! Если вы не уверены в содержании данного архива(не представлен доверенными лицами), то воздержитесь от установки, т.к. это может повлечь необратимые последствия!</font>
                                                        </div>
														<button type="submit" class="btn btn-info">Установить</button>									
                                                    </form>												
													<div id="_div"></div>
                                                </div>
                                            </section>
                                        </div>
                                    </div>';       
				
		$adminTpl->admin_foot();
		break;
		
		
	case 'ajax':		
		$versions[1] = VERSION_ID;
		switch(isset($url[3]) ? $url[3] : '')
		{
			default:
				$response = gzinflate(@file_get_contents($server_domain.'modules.php?main'));
				$cat_list = explode('|', @file_get_contents($server_domain.'modules.php?cat_list'));
				if(!empty($cat_list))
				{
					foreach($cat_list as $li)
					{
						$cat_li = explode('-', $li);
						$min[$cat_li[1]] = $cat_li[0];
					}
				}			
				echo '<table class="table no-margin">
										<thead>
											<tr>												
												<th class="col-md-2"><span class="pd-l-sm"></span>Название</th>
												<th class="col-md-4">Описание</th>
												<th class="col-md-2">Автор</th>
												<th class="col-md-1">Тип</th>
												<th class="col-md-1">Версия</th>
												<th class="col-md-3">Версия JMY CMS</th>
												<th class="col-md-1">' . _ACTIONS . '</th>
											</tr>
										</thead>
										<tbody>';    		
				
				$modules = unserialize($response);
				
				foreach($modules as $mod => $info)
				{
					echo '<tr>
								<td><span class="pd-l-sm"></span>'.$info['title'].'</td>
								<td>'.$info['description'].'</td>
								<td>'.$info['author'].'</td>
								<td>'.$info['cat'].'</td>
								<td>'.$info['version'].'</td>
								<td>'.$info['version_jmy'].'</td>
								<td><a href="javascript:;" class="btn btn-success btn-xs">Установить</a></td>										
							</tr>';
									
					//echo '<div class="_module_boxes"><div class="_buts">' . (isset($core->tpl->modules[$mod]) ? '<div class="_but _butdel"><a href="javascript:void(0)" onclick="ajaxGet(\'' . ADMIN . '/modules/ajax/delete/' . $mod . '/' . $core->tpl->modules[$mod]['id'] . '\', \'_div\');">Удалить</a></div>' : '<div class="_but"><a href="javascript:void(0)" onclick="gid(\'_div\').innerHTML = \'Идёт установка модуля...\'; ajaxGet(\'' . ADMIN . '/modules/ajax/install/' . $mod . '\', \'_div\');">Установить</a></div>') . '<div class="_version ' . (!empty($info['for_toogle']) && $info['for_toogle'] != VERSION_ID ? (VERSION_ID > $info['for_toogle'] ? '_version2' : '_butdel') : (!empty($info['for_toogle']) ? '' : '_version3')) . '">' . (isset($info['for_toogle']) && isset($versions[$info['for_toogle']]) ? $versions[$info['for_toogle']] : 'N/A') . '</div></div><div class="_module_title">' . $info['title'] . ' (' . $mod . ')</div><p>' . $info['description'] . '</p><b>Версия модуля:</b> ' . $info['version'] . '<br /><b>Раздел:</b> <a href="javascript:void(0)" onclick="ajaxGet(\'' . ADMIN . '/modules/ajax/cat/' . $info['cat'] . '\', \'_div\'); setbold(\'' . $info['cat'] . '\'); bold = \'' . $info['cat'] . '\';">'.$min[$info['cat']].'</a></div>';
				}
				echo '</tbody></table>';
				break;
				
			case 'cat':
				if(isset($url[4]))
				{	
					$response ='';
					if (file_get_contents($server_domain.'modules.php?cat_'.$url[4]) != 'empty')
					{
					$response = gzinflate(@file_get_contents($server_domain.'modules.php?cat_'.$url[4]));
					}
					if(empty($response))
					{
						echo '<div class="panel-heading" >Раздел не сушествует или он пуст!</div>';
					}
					else
					{
						$cat_list = explode('|', @file_get_contents($server_domain.'modules.php?cat_list'));
						if(!empty($cat_list))
						{
							foreach($cat_list as $li)
							{
								$cat_li = explode('-', $li);
								$min[$cat_li[1]] = $cat_li[0];
							}
						}
						echo '<table class="table no-margin">
										<thead>
											<tr>												
												<th class="col-md-2"><span class="pd-l-sm"></span>Название</th>
												<th class="col-md-4">Описание</th>
												<th class="col-md-2">Автор</th>
												<th class="col-md-1">Тип</th>
												<th class="col-md-1">Версия</th>
												<th class="col-md-3">Версия JMY CMS</th>
												<th class="col-md-1">' . _ACTIONS . '</th>
											</tr>
										</thead>
										<tbody>';    	
						$modules = unserialize($response);
						foreach($modules as $mod => $info)
						{
							echo '<tr>
								<td><span class="pd-l-sm"></span>'.$info['title'].'</td>
								<td>'.$info['description'].'</td>
								<td>'.$info['author'].'</td>
								<td>'.$info['cat'].'</td>
								<td>'.$info['version'].'</td>
								<td>'.$info['version_jmy'].'</td>
								<td><a href="javascript:;" class="btn btn-success btn-xs">Установить</a></td>										
							</tr>';
							/*
							echo '<div class="_module_boxes"><div class="_buts">' . (isset($core->tpl->modules[$mod]) ? '<div class="_but _butdel"><a href="javascript:void(0)" onclick="ajaxGet(\'' . ADMIN . '/modules/ajax/delete/' . $mod . '/' . $core->tpl->modules[$mod]['id'] . '\', \'_div\');">Удалить</a></div>' : '<div class="_but"><a href="javascript:void(0)" onclick="gid(\'_div\').innerHTML = \'Идёт установка модуля...\'; ajaxGet(\'' . ADMIN . '/modules/ajax/install/' . $mod . '\', \'_div\');">Установить</a></div>') . '<div class="_version ' . (!empty($info['for_toogle']) && $info['for_toogle'] != VERSION_ID ? (VERSION_ID > $info['for_toogle'] ? '_version2' : '_butdel') : (!empty($info['for_toogle']) ? '' : '_version3')) . '">' . (isset($info['for_toogle']) && isset($versions[$info['for_toogle']]) ? $versions[$info['for_toogle']] : 'N/A') . '</div></div><div class="_module_title">' . $info['title'] . ' (' . $mod . ')</div><p>' . $info['description'] . '</p><b>Версия модуля:</b> ' . $info['version'] . ($url[4] == 'all' ? '<br /><b>Раздел:</b> <a href="javascript:void(0)" onclick="ajaxGet(\'' . ADMIN . '/modules/ajax/cat/' . $info['cat'] . '\', \'_div\'); setbold(\'' . $info['cat'] . '\'); bold = \'' . $info['cat'] . '\';">'.$min[$info['cat']].'</a>' : '') . '</div>';*/
						}
						echo '<script type="text/javascript">var bold = \'\'; function setbold(id) { if(bold != \'\') {gid(bold).style.fontWeight=\'normal\'; }  gid(id).style.fontWeight=\'bold\'; } </script>';
					}
				}
				else
				{
						echo '<div class="panel-heading" >Раздел не сушествует или он пуст!</div>';
				}
				break;
				
			case 'search':
				if(isset($url[4]))
				{
					if(!empty($url[4]))
					{
						$response = gzinflate(@file_get_contents($server_domain.'server.php?search='.urlencode($url[4])));
						$search = unserialize($response);
						if(empty($search))
						{
							echo '<div class="_module_cat">Поиск по запросу "' . $url[4] . '"</div>';
							echo '<div class="_inff _redinf" style="margin:0;"><span style="font-size:14px; font-weight:bold;">Поиск завершён</span><br />К сожалению ни одной записи не найдено.</div>';
						}
						else
						{
							$cat_list = explode('|', @file_get_contents($server_domain.'module_categories.text'));
							if(!empty($cat_list))
							{
								foreach($cat_list as $li)
								{
									$cat_li = explode('-', $li);
									$min[$cat_li[1]] = $cat_li[0];
								}
							}
							echo '<div class="_module_cat">Поиск по запросу "' . $url[4] . '", ' . count($search) . ' результ.</div>';
							foreach($search as $mod => $info)
							{
								echo '<div class="_module_boxes"><div class="_buts">' . (isset($core->tpl->modules[$mod]) ? '<div class="_but _butdel"><a href="javascript:void(0)" onclick="ajaxGet(\'' . ADMIN . '/modules/ajax/delete/' . $mod . '/' . $core->tpl->modules[$mod]['id'] . '\', \'_div\');">Удалить</a></div>' : '<div class="_but"><a href="javascript:void(0)" onclick="gid(\'_div\').innerHTML = \'Идёт установка модуля...\'; ajaxGet(\'' . ADMIN . '/modules/ajax/install/' . $mod . '\', \'_div\');">Установить</a></div>') . '<div class="_version ' . (!empty($info['for_toogle']) && $info['for_toogle'] != VERSION_ID ? (VERSION_ID > $info['for_toogle'] ? '_version2' : '_butdel') : (!empty($info['for_toogle']) ? '' : '_version3')) . '">' . (isset($info['for_toogle']) && isset($versions[$info['for_toogle']]) ? $versions[$info['for_toogle']] : 'N/A') . '</div></div><div class="_module_title">' . $info['title'] . ' (' . $mod . ')</div><p>' . $info['description'] . '</p><b>Версия модуля:</b> ' . $info['version'] . ($url[4] == 'all' ? '<br /><b>Раздел:</b> <a href="javascript:void(0)" onclick="ajaxGet(\'' . ADMIN . '/modules/ajax/cat/' . $info['cat'] . '\', \'_div\'); setbold(\'' . $info['cat'] . '\'); bold = \'' . $info['cat'] . '\';">'.$min[$info['cat']].'</a>' : '') . '</div>';
							}
							echo '<script type="text/javascript">var bold = \'\'; function setbold(id) { if(bold != \'\') {gid(bold).style.fontWeight=\'normal\'; }  gid(id).style.fontWeight=\'bold\'; } </script>';
						}
					}
					else
					{
						echo '<div class="_module_cat">Поиск по модулям</div>';
						echo '<div class="_inff _redinf" style="margin:0;"><span style="font-size:14px; font-weight:bold;">Произошла ошибка</span><br />Поисковый запрос не может быть пустым</div>';
					}
				}
				break;
				
			case 'install':
				if(isset($url[4]))
				{
					if(!eregStrt('.zip', $url[4]))
					{
						$response = gzinflate(@file_get_contents($server_domain.'server.php?install='.$url[4]));
						$arr = unserialize($response);
						$zip = $server_domain.$arr[0];
					}
					elseif(eregStrt('.zip', $url[4]))
					{
						$zip = $url[4];
						$arr[1] = basename($zip);
					}
					
					if(!empty($arr[0]) && !isset($core->tpl->modules[$url[4]]) && ($file_content = @file_get_contents($zip)))
					{
						
						$file = fopen (ROOT."tmp/temp_install.zip", "w");
						fputs ($file, $file_content);
						fclose ($file);
						@chmod_R(ROOT."tmp/temp_install.zip", 0666);
						require_once(ROOT.'boot/sub_classes/pclzip.lib.php');
						$archive = new PclZip(ROOT."tmp/temp_install.zip");
						if(($v_result_list = $archive->extract(PCLZIP_OPT_PATH, ROOT)) == 0)
						{
							echo '<div class="_module_cat">Установка модуля</div>';
							echo '<div class="_inff _redinf" style="margin:0;"><span style="font-size:14px; font-weight:bold;">Ошибка</span><br />Архив не соответсвует стандарту</div>';
						}
						else
						{
							if(file_exists(ROOT.'usr/modules/' . $url[4] . '/sql.sql'))
							{
								$sql = @file_get_contents(ROOT.'usr/modules/' . $url[4] . '/sql.sql');
								if(!empty($sql))
								{
									if(!eregStrt('[prefix]_users', $sql)) $db->query(str_replace('[prefix]', DB_PREFIX, $sql));
									$sql = true;
								}
							}
							
							$file = fopen (ROOT."usr/modules/" . $url[4] . "/report", "w");
							fputs ($file, serialize($v_result_list));
							fclose ($file);
							
							$db->query("INSERT INTO `" . DB_PREFIX . "_plugins` (`title` , `content` , `service`  , `active` ) VALUES ('" . $db->safesql($url[4]) . "', '" . $db->safesql($arr[1]) . "', 'modules', '1');");
							delcache('plugins');
							echo '<div class="_module_cat">Установка модуля</div>';
							echo '<div class="_inff" style="margin:0;"><span style="font-size:14px; font-weight:bold;">Действие выполнено</span><br />Модуль успешно установлен на сайт. ' . (isset($sql) ? 'Необходимые запросы выполнены в базу данных' : '') . '</div>';
						}

						//if(file_exists(
						@unlink(ROOT."tmp/temp_install.zip");
					}
					else
					{
						echo '<div class="_module_cat">Установка модуля</div>';
						echo '<div class="_inff _redinf" style="margin:0;"><span style="font-size:14px; font-weight:bold;">Ошибка</span><br />Произошла ошибка при установке модуля. Приносим свои извенения за неудобства</div>';
					}
				}
				break;
	
	case 'delete':
				if(isset($url[4]) && isset($url[5]))
				{
					delete(intval($url[5]), $url[4]);
					echo '<div class="_module_cat">Удаление модуля</div>';
					echo '<div class="_inff" style="margin:0;"><span style="font-size:14px; font-weight:bold;">Действие выполнено</span><br />Модуль успешно удалён с сайта.</div>';
				}
				break;
		}
		break;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		/*
	case 'ajax':
		$versions[1] = 'RC3';
		switch(isset($url[3]) ? $url[3] : '')
		{							
			case 'delete':
				if(isset($url[4]) && isset($url[5]))
				{
					delete(intval($url[5]), $url[4]);
					echo '<div class="_module_cat">Удаление модуля</div>';
					echo '<div class="_inff" style="margin:0;"><span style="font-size:14px; font-weight:bold;">Действие выполнено</span><br />Модуль успешно удалён с сайта.</div>';
				}
				break;
		}
		break;
	*/
	case 'edit':
		if(isset($url[3])) 
		{
			$modId = $url[3];
			$query = $db->query("SELECT * FROM ".DB_PREFIX."_plugins WHERE id = '" . $modId . "'");
			$module = $db->getRow($query);
			$title = $module['content'];
			$groups = explode(',', $module['groups']);
			$unshow = explode(',', $module['unshow']);
		} 
		else
		{
			location();
		}

		$adminTpl->admin_head('Модули | Редактировать модуль');
		echo '<div class="row"><div class="col-lg-12"><section class="panel"><div class="panel-heading no-border"><b>Редактирование модуля: '.$title.'</b></div><div class="panel-body"><div class="switcher-content"><form action="{ADMIN}/modules/save" method="post" name="news" role="form" class="form-horizontal parsley-form" data-parsley-validate="" novalidate="">
		
		<div class="form-group">
					<label class="col-sm-3 control-label">Описание модуля:</label>
					<div class="col-sm-4">
					<input type="text" size="20" name="title" class="textinput" value="'.$title.'" maxlength="100" maxsize="100" />
					</div>
		</div>	
		<div class="form-group">
			<label class="col-sm-3 control-label">'._GROUP_ACCESS.'</label>
			<div class="col-sm-4">
			<select name="groups[]" class="cat_select" multiple ><option value="" ' . (empty($groups) ? 'selected' : '') . '>Все группы</option>';
			$query = $db->query("SELECT * FROM `" . USER_DB . "`.`" . USER_PREFIX . "_groups` ORDER BY admin DESC,moderator DESC,user DESC,guest DESC,banned DESC");
			while($rows = $db->getRow($query)) 
			{
				$selected = in_array($rows['id'], $groups) ? "selected" : "";
				echo '<option value="' . $rows['id'] . '" ' . $selected . '>' . $rows['name'] . '</option>';
			}
		echo '</select>
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label"><b>НЕ</b>отображать блоки:</label>
			<div class="col-sm-4">
			<select name="type[]" class="cat_select" multiple>';
			$query = $db->query("SELECT * FROM ".DB_PREFIX."_blocks_types ORDER BY type");
			while($rows = $db->getRow($query)) 
			{
				$selected = in_array($rows['type'], $unshow) ? "selected" : "";
				echo '<option value="' . $rows['type'] . '" ' . $selected . '>' . $rows['title'] . ' [' . $rows['type'] . ']</option>';
			}
		echo '</select>
			</div>
		</div>';
		if(isset($modId)) 
		{
			echo '<input type="hidden" name="id" value="' . $modId . '">';
		}
		echo '<div class="form-group">
					<label class="col-sm-3 control-label"></label>
					<div class="col-sm-4">
						<input name="submit" type="submit" class="btn btn-primary btn-parsley" id="sub" value="'. _UPDATE .'">						
					</div>
		</div></form></div></div></section></div></div>';		
		
		$adminTpl->admin_foot();
		break;
		
		
	case 'save':
		$id = isset($_POST['id']) ? intval($_POST['id']) : '';
		$title = isset($_POST['title']) ? filter($_POST['title'], 'title') : '';
		$type = isset($_POST['type']) ? $_POST['type'] : '';
		$groups = isset($_POST['groups']) ? $_POST['groups'] : false;
		
		$g = 0;
		$groupList = '';
		if(!empty($groups))
		{
			foreach($groups as $group)
			{
				if(trim($group) !== '')
				{
					$g++;
					if($g == 1)
					{
						$groupList = $group;
					}
					else
					{
						$groupList .= ',' . $group;
					}
				}
			}		
		}
		
		$d = 0;
		$deList = '';
		if(!empty($type))
		{
			foreach($type as $typ)
			{
				if(trim($typ) !== '')
				{
					$d++;
					if($d == 1)
					{
						$deList = $typ;
					}
					else
					{
						$deList .= ',' . $typ;
					}
				}
			}
		}
		
		$adminTpl->admin_head('Модули системы | Редактирование');
		if(!empty($title))
		{
			$db->query("UPDATE `" . DB_PREFIX . "_plugins` SET `content` = '" . $title . "' , `unshow` = '" . $deList . "', `groups` = '" . $groupList . "' WHERE `id` =" . $id . " LIMIT 1 ;");
			delcache('plugins');
			$adminTpl->info('Модуль успешно обновлён. <a href="{ADMIN}/modules">Просмотреть список модулей</a>');
		}
		else
		{

		}
		
		$adminTpl->admin_foot();
			
		break;
	
	
	case "delete":
		$id = intval($url[3]);
		$path = filter($url[4]);
		delete($id, $path);
		delcache('plugins');
		location(ADMIN.'/modules/ok');
	break;
	
	case "retivate":
		$id = intval($url[3]);
		retivate($id);
		delcache('plugins');
		location(ADMIN.'/modules/ok');
	break;	
	
	case 'action':
		foreach($_POST['checks'] as $id) 
		{
			retivate(intval($id));
		}
		delcache('plugins');
		location(ADMIN.'/modules/ok');
		break;
	
}