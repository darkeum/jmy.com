<?php

$descr = 'ShadowBox';

$js = '<link rel="stylesheet" type="text/css" href="media/imageEffects/shadowbox/shadowbox.css" />
<script type="text/javascript" src="media/imageEffects/shadowbox/shadowbox.js"></script>
<script type="text/javascript">
Shadowbox.init();
</script>';

$picture = '<a href="{full}" rel="shadowbox[default]" {href}><img src="{thumb}" border="0" {img} /></a>';