<?php

/**
* @name        JMY CMS
* @link        http://jmy.su/
* @copyright   Copyright (C) 2012-2014 JMY LTD
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      Komarov Ivan
* @edit 	   03.02.2015
*/

define('_G_GUESTBOOK', 'Guest book');
define('_G_EDIT', 'Editing');
define('_G_COM', 'Comment');
define('_G_REPLY', 'Answer');
define('_G_REPLY_EDIT', 'Edit answer');
define('_G_REPLY_UPDATE', 'The answer successfully updated!');
define('_G_DEL', 'Delete comment');
define('_G_EMPTY', 'Guest book is empty!');
define('_G_INFO', 'Information about comments');
define('_G_TEXT', 'Comment text');

