<?php

/**
* @name        JMY CMS
* @link        http://jmy.su/
* @copyright   Copyright (C) 2012-2016 JMY LTD
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      Komarov Ivan
*/

define('_SENDINGMESS', 'Message sending');
define('_SENDOK', 'Your message is sent');
define('_SENDFALSE', 'Obligatory fields of the form are not filled, return back and fill missing fields!');
define('_CAPTCHAFALSE', 'The code captcha is entered incorrectly!');
define('_MESSAGE_THEME', 'Message theme');
define('_MESSAGE', 'Message');

define('_MESSAGE_TITLE', 'Message');