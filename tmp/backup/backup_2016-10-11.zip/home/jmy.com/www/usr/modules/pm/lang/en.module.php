<?php

/**
* @name        JMY CMS
* @link        http://jmy.su/
* @copyright   Copyright (C) 2012-2015 JMY LTD
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      Komarov Ivan
*/

define('_PM_TITLE', 'Private messages');
define('_PM_WRITE', 'Write');
define('_PM_INBOX', 'Inbox');
define('_PM_SENTBOX', 'Outbox');
define('_PM_DRAFTCOPY', 'Draught copies');
define('_ADD_PM', 'Send PM');
define('_PM_MESSAGE', 'Message');
define('_PM_DATE', 'Date');
define('_PM_NOT_READ', 'It is not read');
define('_PM_READ', 'It is read');
define('_PM_DELETE_MESSAGE', 'Delete message');
define('_PM_DELETE', 'Delete');
define('_PM_DELETE_INFO', 'Are assured that want to remove noted messages?');
define('_PM_READS', 'Read');
define('_PM_FROM', 'From whom');
define('_PM_WHOM', 'To whom');
define('_PM_ANSWER_MESSAGE', 'Answer the message');
define('_PM_STATUS', 'Status');
define('_PM_VIEW_MESSAGE', 'Message viewing');
define('_', '');