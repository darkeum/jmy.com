<?php

/**
* @name        JMY CMS
* @link        http://jmy.su/
* @copyright   Copyright (C) 2012-2014 JMY LTD
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      Komarov Ivan
*/

define('_G_GUESTBOOK', 'Гостевая книга');
define('_G_EDIT', 'Редактирование');
define('_G_COM', 'Комментарий');
define('_G_REPLY', 'Ответ');
define('_G_WEBSITE', 'Вебсайт');
define('_G_REPLY_EDIT', 'Редактировать ответ');
define('_G_REPLY_UPDATE', 'Ответ успешно обнолён!');
define('_G_DEL', 'Удалить комментарий');
define('_G_EMPTY', 'Гостевая книга пуста!');
define('_G_INFO', 'Информация о комментарии');
define('_G_TEXT', 'Текст комментария');
define('_G_NULL', 'Записи отсутствуют, Вы будите первым!');
define('_G_REPLY_1', 'Есть ответ!');
define('_G_REPLY_0', 'Ответ не найден!');
define('_G_WEBSITE_0', 'Вебсайт не указан');
define('_SENDINGMESS', 'Отправка сообщения');
define('_SENDOK', 'Ваше сообщение отправлено');
define('_SENDFALSE', 'Не заполнены обязательные поля формы, вернитесь назад и заполните недостающие поля!');
define('_SENDFALSE_0', 'Что-то пошло не так! Повторите ещё раз!');
define('_CAPTCHAFALSE', 'Код каптчи введён неверно!');
