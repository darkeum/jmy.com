<?php

/**
* @name        JMY CMS
* @link        http://jmy.su/
* @copyright   Copyright (C) 2012-2014 JMY LTD
* @license     LICENSE.txt (see attached file)
* @version     VERSION.txt (see attached file)
* @author      Komarov Ivan
*/

if (!defined('ACCESS')) {
	header('Location: /');
	exit;
}


$module_array['sendmail'] = array(
		'name' => _ADMIN_MOD_SM,
		'icon' => 'media/admin/pages.png',
		'desc' => _ADMIN_MOD_SM_DESC,
		'subAct' => array(
			_ADMIN_MOD_SM_LIST => '',
			_ADMIN_MOD_SM_USERS => 'users',
			_ADMIN_MOD_SM_ADD => 'add',						
			_ADMIN_MOD_SM_CONFIG => 'config',
		)
);

$toconfig['sendmail'] = array
(
'name' => _ADMIN_MOD_SM_NEWSLETTER_POSTS,
'link' => 'module/sendmail/config',
'param' => 'sendmail_conf'
);