$("document").ready(function(){
    $('a[href*=#]').anchor({
        transitionDuration : 1200
    });
});