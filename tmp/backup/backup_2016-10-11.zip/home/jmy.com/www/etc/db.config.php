<?php
if (!defined('ACCESS')) 
{
    header('Location: /');
    exit;
}


$dbhost = 'localhost';
$dbuser = '11';
$dbpass = '11';
$dbname = '11';

$prefix = 'JMY';
$user_prefix = 'JMY';
$user_db = '11';

