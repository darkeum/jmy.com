<?php

if (!defined('ADMIN_SWITCH')) {
    header('Location: /');
    exit;
}

function sendmail_main() 
{
	require (ROOT.'etc/sendmail.config.php');
	global $adminTpl, $core, $db, $admin_conf, $sendmail_conf;
	$adminTpl->admin_head(_ADMIN_MOD_SM);
	echo '<div id="content" class="animated fadeIn">';
	$page = init_page();
	$limit = ($page-1)*$sendmail_conf['message_num'];
	$query = $db->query("SELECT * FROM " . DB_PREFIX . "_sm_mail WHERE uid='0' ORDER BY id DESC LIMIT " . $limit . ", " . $sendmail_conf['message_num'] . "");
	if($db->numRows($query) > 0)
	{
echo '
<div class="row">
<div class="col-lg-12">
<section class="panel">
<div class="panel-heading">
<b>' . _ADMIN_MOD_SM_LIST . '</b>
</div>
<div class="panel-body no-padding">
<table class="table no-margin">
<thead>
<tr>
<th width="35%" class="text-center">' . _ADMIN_MOD_SM_TOPIC . '</th>
<th width="35%" class="text-center">' . _ADMIN_MOD_SM_TEXT . '</th>
<th width="15%" class="text-center">' . _ADMIN_MOD_SM_DATE . '</th>
<th width="15%" class="text-center">' . _ACTIONS . '</th>
</tr>
</thead>
<tbody>
';
while($sendmail = $db->getRow($query)) 
{
echo '
<tr>
<td><strong>'.$sendmail['topic'].'</strong></td>
<td>'.$sendmail['text'].'</td>
<td class="text-center">'.formatDate($sendmail['date'], true).'</td>
<td class="text-center">
<a href="{MOD_LINK}/delete/' . $sendmail['id'] . '" onClick="return getConfirm(\'' . _DELETE .' - ' . $sendmail['id'] . '?\')">
<button type="button" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="' . _DELETE .'">X</button>
</a>
</td>
</tr>';
}
echo '
</tbody>
</table>
</div>';
echo '
<div class="panel-heading">';
$all_query = $db->query("SELECT * FROM " . DB_PREFIX . "_sm_mail ");
$all = $db->numRows($all_query);
$adminTpl->pages($page, $sendmail_conf['message_num'], $all, ADMIN.'/module/sendmail/{page}');
echo '
</div>';
echo '
</section>
</div>
</div>';
}
else 
{ 
$adminTpl->info(_ADMIN_MOD_SM_EMPTY, 'empty', null, _ADMIN_MOD_SM_LIST, _ADMIN_MOD_SM_ADD, ADMIN.'/module/sendmail/add');			
}
echo '</div>';
$adminTpl->admin_foot();
}

function sendmail_users() 
{
require (ROOT.'etc/sendmail.config.php');	
global $adminTpl, $core, $db, $admin_conf, $sendmail_conf;
$adminTpl->admin_head(_ADMIN_MOD_SM_LIST_USERS);
$page = init_page();
$limit = ($page-1)*$sendmail_conf['users_num'];
echo '
<div class="row">
<div class="col-lg-12">
<section class="panel">
<div class="panel-heading">
<b>' . _ADMIN_MOD_SM_LIST_USERS . '</b>
</div>';
$query = $db->query("SELECT * FROM " . DB_PREFIX . "_sm_users ORDER BY user_id DESC LIMIT " . $limit . ", " . $sendmail_conf['users_num'] . "");
if($db->numRows($query) > 0)
{
echo '
<div class="panel-body no-padding">
<table class="no-margin">
<thead>
<tr>
<th width="35%">' . _ADMIN_MOD_SM_USER_NAME . '</th>
<th width="35%" class="text-center">' . _ADMIN_MOD_SM_USER_EMAIL . '</th>
<th width="15%" class="text-center">' . _ADMIN_MOD_SM_USER_DATE . '</th>
<th width="15%" class="text-center">' . _ACTIONS . '</th>
</tr>
</thead>
<tbody>
';
while($sendmail = $db->getRow($query)) 
{

$status_icon = ($sendmail['active'] == 0) ? '
<a href="{MOD_LINK}/activate/' . $sendmail['user_id'] . '" onClick="return getConfirm(\'' . _ADMIN_MOD_SM_SUBSCRIBE .' - ' . $sendmail['user_email'] . '?\')"><button  type="button" class="btn btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="' . _ADMIN_MOD_SM_SUBSCRIBE .'">A</button></a>' : 
'<a href="{MOD_LINK}/deactivate/' . $sendmail['user_id'] . '" onClick="return getConfirm(\'' . _ADMIN_MOD_SM_UNSUBSCRIBE_ATTENTION .' - ' . $sendmail['user_email'] . '?\')" ><button  type="button" class="btn btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="' . _ADMIN_MOD_SM_UNSUBSCRIBE_ATTENTION .'">A</button></a>
<button id="' . $sendmail['user_id'] . '" type="button" class="btn btn-icon command-edit" data-toggle="tooltip" data-placement="top" title="' . _ADMIN_MOD_SM_SUBSCRIBE .'"><span class="mdi mdi-check"></span></button>';

echo '
<tr '.(($sendmail['active'] == 0) ? 'class="danger"' : '' ).'>
<td>'.$sendmail['user_name'].'</td>
<td class="text-center">'.$sendmail['user_email'].'</td>
<td class="text-center">'.formatDate($sendmail['user_reg_date'], true).'</td>
<td class="text-center">' . $status_icon . '</td>
</tr>';
}
echo '
</tbody>
</table>
</div>';
echo '
<div class="panel-heading">';
$all_query = $db->query("SELECT * FROM " . DB_PREFIX . "_sm_users ");
$all = $db->numRows($all_query);
$adminTpl->pages($page, $sendmail_conf['users_num'], $all, ADMIN.'/module/sendmail/users/{page}');
echo '
</div>';
}
else 
{ 
echo '<div class="panel-heading">' . _ADMIN_MOD_SM_SUBSCRIBERS_EMPTY . '</div>';			
}
echo '
</section>
</div>
</div>';
$adminTpl->admin_foot();
}

function sendmail_add() 
{
require (ROOT.'etc/sendmail.config.php');
global $adminTpl, $core, $db, $core, $config;

$nameconf = $sendmail_conf['name'];
$emailconf = $sendmail_conf['email'];

if (isset($_POST["act"])) {
	$topic = isset($_POST['topic']) ? filter($_POST['topic']) : '';
	$text = isset($_POST['text']) ? filter($_POST['text']) : '';
	$uid = isset($_POST['uid']) ? filter($_POST['uid']) : '';
	$date = time();
    if(!empty($topic) && !empty($text) && !empty($date)) {
    $query = $db->query("INSERT INTO `" . DB_PREFIX . "_sm_mail` (`topic`,`text`,`date`) 
                        VALUES ('".$_POST['topic']."','".$_POST['text']."','{$date}')");

if ($query == 'true') {
//отправка подписчикам
$query = $db->query("SELECT `user_email`,`user_name` 
								FROM `" . DB_PREFIX . "_sm_users` WHERE `active`='1'",$db);

if($db->numRows($query) > 0) {
$sendmail = $db->getRow($query); 
							do 
								{
$headers=null;
$headers.='Content-Type: text/html; charset=' . $config['charset'] . '\r\n';
$headers.='From: ' . $sendmail_conf['name'] . ' <' . $sendmail_conf['email'] . '>\r\n';
$headers.='X-Mailer: JMY Mail\r\n';
$msg='
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=' . $config['charset'] . '">
<style>BODY {FONT-FAMILY: verdana,arial,helvetica; FONT-SIZE: 12px; COLOR: #333} TD {FONT-SIZE: 12px; COLOR: #333} .sm {FONT-SIZE: 9px;}</style>
</head>
<body>									
<table bgcolor="#FFFFFF" width="700" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
<td width="230"><a target="_blank" href="' . $config['url'] . '">' . $config['name'] . '</a></td>
<td>Здравствуйте, <strong>'.$sendmail['user_name'].'</strong></td>
</tr>
<tr>
<td colspan=2><h3>'.$topic.'</h3><br/>'.$text.'</td>
</tr>									
</table><br /><br /><br /><br /><hr />
<center>С уважением, администрация ' . $config['name'] . '</center>
</body>
</html>';
$email = $sendmail['user_email'];
mail($email, ''.$sendmail_conf['name'], $msg, $headers);
}
while($sendmail = $db->getRow($query));
}
$adminTpl->info(_ADMIN_MOD_SM_NEWSLETTER_SUCCESS);
} else {
$adminTpl->info(_ADMIN_MOD_SM_NEWSLETTER_ERROR, 'error');
		}

 		}   
}	
	
	$adminTpl->admin_head(_ADMIN_MOD_SM_ADDING);	
	echo '
<div class="row">
<div class="col-lg-12">
<section class="panel">
<div class="panel-heading no-border">
<b>' . _ADMIN_MOD_SM_ADDING . '</b>
</div>
<div class="panel-body">
<form action="" method="post" role="form">
<div class="form-group">
<label class="col-sm-3 control-label">' . _ADMIN_MOD_SM_TOPIC . '</label>
<div class="col-sm-9">
<input type="text" name="topic" id="topic" class="form-control">
</div>
</div>
<div class="form-group">
<label col-sm-12 control-label">' . _ADMIN_MOD_SM_TEXT . '</label>
</div>';
echo adminArea('text', $text, 10, 'textarea', false, true);
echo '
</div>
<div class="panel-heading no-border">
<input type="hidden" name="act" value="act" />
<button name="submit" type="submit" class="btn btn-primary" id="sub"/>' . _ADMIN_MOD_SM_DISTRIBUTE . '</button>
</div>';	
echo '
</form>
</section>
</div>
</div>';

		$adminTpl->admin_foot();
}

function activate($id) {
global $adminTpl, $db;
	$db->query("UPDATE `" . DB_PREFIX . "_sm_users` SET `active` = '1' WHERE `user_id` = " . $id . " LIMIT 1 ;");
}

function delete($id) {
global $adminTpl, $db;
	$db->query("DELETE FROM `" . DB_PREFIX . "_sm_mail` WHERE `id` = " . $id . " LIMIT 1");	
}

switch(isset($url[3]) ? $url[3] : null) {
	default:
		sendmail_main();
	break;

	case "add":
		sendmail_add();
	break;
	
	case "save":
		sendmail_save();
	break;
	
	case "users":
		sendmail_users();
	break;

	case "activate":
		$id = intval($url[4]);
		$db->query("UPDATE `" . DB_PREFIX . "_sm_users` SET `active` = '1' WHERE `user_id` = " . $id . " LIMIT 1 ;");
		$query = $db->query("SELECT * FROM ".DB_PREFIX."_sm_users WHERE user_id = '" . $id . "'");
		location(ADMIN.'/module/sendmail/users');
	break;	
	
	case "deactivate":
	global $adminTpl, $db;
		$id = intval($url[4]);
		$db->query("UPDATE `" . DB_PREFIX . "_sm_users` SET `active` = '0' WHERE `user_id` = " . $id . " LIMIT 1 ;");
		$query = $db->query("SELECT * FROM ".DB_PREFIX."_sm_users WHERE user_id = '" . $id . "'");
		location(ADMIN.'/module/sendmail/users');
	break;

	case "delete":
		$id = intval($url[4]);
		delete($id);
		header('Location: /'.ADMIN.'/module/sendmail/');
	break;
	
	case 'config':
		require (ROOT.'etc/sendmail.config.php');
		
		$configBox = array(
			'sendmail' => array(
				'varName' => 'sendmail_conf',
				'title' => _ADMIN_MOD_SM_CONFIG,
				'groups' => array(
					'main' => array(
						'title' => _ADMIN_MOD_SM_CONFIG_MAIN,
						'vars' => array(
							'name' => array(
								'title' => _ADMIN_MOD_SM_CONFIG_NAME,
								'description' => _ADMIN_MOD_SM_CONFIG_NAME_DESC,
								'content' => '<input type="text" size="20" name="{varName}" class="form-control" value="{var}" />',
							),
							'email' => array(
								'title' => _ADMIN_MOD_SM_CONFIG_EMAIL,
								'description' => _ADMIN_MOD_SM_CONFIG_EMAIL_DESC,
								'content' => '<input type="text" size="20" name="{varName}" class="form-control" value="{var}" />',
							),
							'message_num' => array(
								'title' => _ADMIN_MOD_SM_CONFIG_MAIL,
								'description' => _ADMIN_MOD_SM_CONFIG_MAIL_DESC,
								'content' => '<input type="text" size="20" name="{varName}" class="form-control" value="{var}" />',
							),
							'users_num' => array(
								'title' => _ADMIN_MOD_SM_CONFIG_USERS,
								'description' => _ADMIN_MOD_SM_CONFIG_USERS_DESC,
								'content' => '<input type="text" size="20" name="{varName}" class="form-control" value="{var}" />',
							),							
						)
					),

				),
			),
		);
		$ok = false;		
		if(isset($_POST['conf_file']))
		{
			$ok = true;
		}		
		generateConfig($configBox, 'sendmail', '{MOD_LINK}/config', $ok);
		break;
}






