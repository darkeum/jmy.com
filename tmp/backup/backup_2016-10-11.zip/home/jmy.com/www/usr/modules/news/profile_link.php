<?php
$core->loadModLang('news');
$linkIcon['news'] = '<img src="media/other/add_news.png" border="0" style="vertical-align:middle" />';
$link['news'] = '<a href="news/addPost" title="' . _ADD_NEWS . '">' . _ADD_NEWS . '</a>';